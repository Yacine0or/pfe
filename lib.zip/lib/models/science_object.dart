class ScienceObject{
  String branche,name,time,type,id,qr,day,room;

  ScienceObject(
      {required this.branche,
        required this.name,
        required this.time,
        required this.type,
        required this.id,
        required this.qr,
        required this.day,
      required this.room});
}